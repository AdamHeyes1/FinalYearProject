<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>

<?php
if (isset($_SESSION['usersId'])){
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Signup page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

<?php
    //If the user has succesfully created an account, notify them
    if (isset($_GET["error"])) {
        if ($_GET["error"] == "success") {
            echo '<div class="signup-success-alert">
                    <div class="alert alert-success" role="alert" style="max-width: 1000px;">Account created successfully!</div>
                  </div>';
        }
    }
    
?>
<!-- Make sure the body covers the height of the screen -->
<body class="d-flex flex-column min-vh-100">  
    <main class="flex-grow-1 d-flex align-items-center justify-content-center"> 
        <div class="container bg-white shadow-lg p-3 p-md-5 rounded my-2 my-md-4 w-100" style="max-width: 85%;">
            <!-- Container for the form -->
            <h2 class="text-custom mb-4">Create An Account</h2> 
            <form action="../includes/signup.inc.php" method="post">
                <!-- user inputs -->
                <div class="row mb-3"> 
                    
                <?php
                //check for errors
                if(isset($_GET["error"])){
                    if($_GET["error"] == "emptyinput"){
                        echo '<div class="alert alert-danger" role="alert">Fill in all fields!</div>';
                    }
                    else if($_GET["error"] == "invalidUsername"){
                        echo '<div class="alert alert-danger" role="alert">Choose a proper username!</div>';
                    }
                    else if($_GET["error"] == "invalidEmail"){
                        echo '<div class="alert alert-danger" role="alert">Choose a proper email!</div>';
                    }
                    else if($_GET["error"] == "pwdConfirmError"){
                        echo '<div class="alert alert-danger" role="alert">Passwords dont match!</div>';
                    }
                    else if($_GET["error"] == "stmtfailed"){
                        echo '<div class="alert alert-danger" role="alert">Something went wrong, try again!</div>';
                    }
                    else if($_GET["error"] == "usernameTaken"){
                        echo '<div class="alert alert-danger" role="alert">Username taken, choose a different username!</div>';
                    }
                    else if($_GET["error"] == "invalidPassword"){
                        echo '<div class="alert alert-danger" role="alert">Your password should contain at least 6 characters and 1 capital letter!</div>';
                    }
                }

                ?>
                <!-- user inputs-->
                <div class="col">
                        <label for="firstname" class="form-label fw-bold">First Name</label>
                        <input type="text" name="firstName" class="form-control" placeholder="First name" id="firstName">
                    </div>
                    <div class="col">
                        <label for="lastName" class="form-label fw-bold">Last Name</label>
                        <input type="text" name="lastName" class="form-control" placeholder="Last name" id="secondName">
                    </div>
                </div>
                <div class="form-group mb-3">
                    <label for="email" class="form-label fw-bold">Email Address</label>
                    <input type="email" name="email" class="form-control" id="email" placeholder="Name@example.com">
                </div>
                <div class="row mb-3">
                    <div class="col">
                    <label for="username" class="form-label fw-bold">Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Username">
                    </div>
                </div>
                <div class="row mb-4">
                    <div class="col">
                    <label for="password" class="form-label fw-bold">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Password">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col">
                        <label for="confirmpassword" class="form-label fw-bold">Confirm Password</label>
                        <input type="password" name="confirmPassword" class="form-control" placeholder="Confirm password">
                    </div>
                </div>
                <div class="form-check mb-4">
                    <input type="checkbox" name="terms" class="form-check-input" id="termsAndConditions" required>
                    <label class="form-check-label" for="termsAndConditions">
                        I agree to the 
                        <a href="../html/privacy-policy.html" target="_blank">Privacy Policy</a> 
                    </label>
                </div>
                <div class="row mb-2">
                    <button type="submit" name="submit" class="btn btn-warning">Create account</button>
                </div>
                <div class="row mb-2">
                <input class="btn btn-outline-danger" type="reset" value="Reset">
                </div>
                <div class="row">
                <a href="login.php" class="btn btn-outline-success">Go to log-in!</a>

                </div>
                
            </form>
        </div>

    </main>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>
<?php include '../includes/footer.php'; ?>

