<?php session_start(); 

if (!isset($_SESSION['usersId'])) {
    header("Location: /5230Comp/CurrentProj1/app/login.php");
    exit();
}?>

<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>
<?php include '../includes/welcomemsg.inc.php'; ?>

<?php
require_once "../includes/dbh.con.inc.php"; 
$current_date = date("Y-m-d");
$usersId = $_SESSION["usersId"];

//Select any records from scores table where the userId matches the current user and the date matches the current date
$sql = "SELECT * FROM scores WHERE usersId = ? AND DATE(quiz_date) = ?";
$stmt = mysqli_stmt_init($conn);

//Pass the users values from the form into the stmt
mysqli_stmt_prepare($stmt, $sql);
mysqli_stmt_bind_param($stmt, "is", $usersId, $current_date);
mysqli_stmt_execute($stmt);
$resultData = mysqli_stmt_get_result($stmt);

mysqli_stmt_close($stmt);

//Initialize lockQuiz
$lockQuiz = false;

//Lock the quiz there is a record of this user taking a quiz today
if($row = mysqli_fetch_assoc($resultData)){
    $lockQuiz = true;
}


//Select all question numbers 
$query = "SELECT question_number FROM `questions`";
$results = $conn->query($query) or die($conn->error . __LINE__);

//Store each question number in array
$questionNumbers = [];
while($row = $results->fetch_assoc()){
	$questionNumbers[] = $row["question_number"];
}

//Randomize the order and make it so there is a maximum of 10 questions
shuffle($questionNumbers);
$_SESSION['questionsArray'] = array_slice($questionNumbers,0,10);

//Initialize variables
$_SESSION['score'] = 0;
$total = count($_SESSION['questionsArray']);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quiz page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

<body>
    <?php
    //Check if user is logged in
    if (isset($_SESSION["usersId"])) { 
    ?>
    <div class="container bg-white shadow-lg rounded my-4 p-5 d-flex flex-column justify-content-center" style="max-width: 80%; min-height: 60%">
        <h2 class="fw-bold mb-3 text-center">Take the daily quiz!</h2>
        <p class="text-muted mb-4 text-center">💸 Get 7 or more correct answers to receive 1,000 more virtual currency!</p>   
        <div class="d-flex flex-column flex-md-row align-items-center justify-content-center gap-3">
        <?php

            //Check if user has already taken quiz today
            if($lockQuiz){
                echo'<button class="btn btn-danger btn-lg">Sorry, you have already taken a quiz today!</button>';
                echo'<a href="viewscores.php" class="btn btn-primary btn-lg" >View scores!</a>';
            }
            //If quiz is not locked, show button to start quiz
            else{
                echo'<a href="question.php?n=0" class="btn btn-success btn-lg">Start Quiz</a>';
                echo'<a href="viewscores.php" class="btn btn-primary btn-lg" >View scores!</a>';
            }
        ?>

        </div>
    </div>

    <?php
    //If user is not logged in, prompt them to the login page
    }
    else{ 
    ?>
    <div class="container bg-white border border-danger border-2 shadow-lg rounded my-4 p-5 d-flex flex-column justify-content-center" style="max-width: 80%; min-height: 60%">
    <h2 class="fw-bold mb-3 text-center">General knowledge quiz!</h2>
    <p class="text-muted mb-4 text-center">Log in or create an account to take our general knowledge quiz!</p>   
    <div class="d-flex flex-column flex-md-row align-items-center justify-content-center gap-3">
            <a href="login.php" class="btn btn-warning btn-lg">Take me to log-in!</a>
            <a href="signup.php" class="btn btn-primary btn-lg" >Create an account!</a>

        </div>
    </div>
    <?php
    }
    ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="../js/script.js"></script>
    </body>
</html>
<?php include '../includes/footer.php'; ?>

