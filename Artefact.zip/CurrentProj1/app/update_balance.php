<?php
//Start session
session_start();
include "../includes/dbh.con.inc.php"; 
//Check if user is logged in
if (!isset($_SESSION["usersId"])){
    die("User not logged in");
}

//Get balance from GET request
if (isset($_GET["newBalance"])){
    //Create variables for newbalance and usersid
    $newBalance = $_GET["newBalance"]; 
    $usersId = $_SESSION["usersId"];

    //Update balance
    $query = $conn->prepare("UPDATE users SET currency = ? WHERE usersId = ? ");
    $query->bind_param("di", $newBalance, $usersId);

    //handle errors
    if ($query->execute()) {
        echo "Balance updated";
    } else {
        echo "Balance updating error";
    }

    $query->close();
    $conn->close();
} else {
    echo "Request error";
}
?>

