<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>
<?php include '../includes/welcomemsg.inc.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

<body>

  <!-- welcome message container-->
  <div class="container welcomeContainer text-center bg-white shadow-lg p-3 rounded my-4">
    <img src="<?php echo $image; ?>" alt="Welcome Image" class="img-fluid rounded mb-4">
      <h1 class="display-4 mb-3 text-custom"><?php echo $title; ?></h1>
    <p class="lead text-muted"><?php echo $description; ?></p>
  </div>
  
  <!-- output nothing if user is logged in, but output promp to create an account if they are not-->
  <?php
  if (isset($_SESSION["usersId"])) { 
  ?>

  <?php
  }
  else{ 
  ?>
  <div class="container my-5">
      <div class="card text-center shadow-lg p-4 bg-light">
          <h3 class="fw-bold">💰 Spend virtual currency!</h3>
          <p class="lead">Receive 1,000 virtual currency upon signing up! 🎉</p>
          <p>Use your virtual currency to play games, and earn more by playing the daily quiz 🏆</p>
          <a href="signup.php" class="btn btn-warning btn-lg mt-3">Sign Up & Receieve 1,000 VC</a>
      </div>
  </div>

  <?php
  }
  ?>


  <!-- main features -->
  <div class="container my-4">
    <h2 class="text-center text-custom mb-4">Main Features</h2>
    <!--js -->
    <div class="row" id="featuresContainer"></div>
  </div>

  <!-- carousel -->
  <div class="container my-4">
    <h2 class="text-center text-custom mb-4">Resources</h2>
    <div id="carousel" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner" id="carousel-inner">
        <!-- js -->
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#carousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#carousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
      </button>
    </div>
  </div>

  <?php 
  //start session and initialize position variable
  session_start();
  $position=1;
  include "../includes/dbh.con.inc.php"; 

  $usersId = $_SESSION['usersId'];
  //Get top 5 virtual currencys from db
  $query = "SELECT currency, usersId, usersUid FROM users ORDER BY currency DESC LIMIT 5";

  //Output leaderboard
  echo ' <div class="container mt-4">
      <h2 class="text-center text-custom mb-4">Leaderboard</h2>
          <table class="table table-hover table-striped table-bordered bg-white">
      <thead class="table-dark">
        <tr> 
            <td> <font face="Arial">🏅Rank</font> </td> 
            <td> <font face="Arial">Username</font> </td> 
            <td> <font face="Arial">Currency</font> </td> 
        </tr>
      </thead>  ';

  //Output data from each result of query
  if ($result = $conn->query($query)) {
      while ($row = $result->fetch_assoc()){
          $field1name = $position;
          $field2name = $row["usersUid"];
          $field3name = $row["currency"];

          echo '<tr> 
                    <td>'.$field1name.'</td> 
                    <td>'.$field2name.'</td> 
                    <td>'.$field3name.'</td> 
                </tr>';

                $position++;

      }
  } 
  ?>
  </table>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
  <script src="../js/script.js"></script>

</body>
</html>
<?php include '../includes/footer.php'; ?>

