
<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>
<?php include '../includes/welcomemsg.inc.php'; 

if (!isset($_SESSION['usersId'])) {
  header("Location: /5230Comp/CurrentProj1/app/login.php");
  exit();
}?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View scores page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

<body class="d-flex flex-column min-vh-100">
  <main class="flex-grow-1">

  <?php 
  session_start();
  include "../includes/dbh.con.inc.php"; 

  //Select the current users scores from scores table
  $usersId = $_SESSION['usersId'];
  $query = "SELECT * FROM scores WHERE usersID = $usersId";

  //Output table columns of date and score
  echo ' <div class="container mt-4">
          <h4 class="mb-2 justify-center">Your Previous Quizzes</h4>

          <table class="table table-hover table-striped table-bordered bg-white">

      <thead class="table-dark">
        <tr> 
            <td><font face="Arial">Date</font></td> 
            <td><font face="Arial">Score</font></td> 
        </tr>
      </thead>  ';

  //Output each row from the query
  if ($result = $conn->query($query)) {
      while ($row = $result->fetch_assoc()){
          $field2name = $row["quiz_date"];
          $field3name = $row["score"];
          echo '<tr> 
                    <td>'.$field2name.'</td> 
                    <td>'.$field3name.'</td> 

                </tr>';
      }
      $result->free();
  } 
  ?>
  </table>
  </div>
 
</main>
<?php include '../includes/footer.php'; ?>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>
