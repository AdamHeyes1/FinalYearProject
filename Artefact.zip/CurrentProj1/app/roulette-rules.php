<!-- static information as these rules will not be changed and therefore do not need to be imported dynamically-->
<!-- https://www.mastersofgames.com/rules/roulette-rules.htm?srsltid=AfmBOoq7PCn9VVxVBR0DbIDaAUl_3vsQvHjQ5ux7dEFhkrFlqj3gfO6F-->

<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Roulette rules</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

<!-- Make sure the body covers the height of the screen -->
<body class="d-flex flex-column min-vh-100">  
<main class="flex-grow-1 d-flex align-items-center justify-content-center">
    <div class="container bg-white shadow-lg p-3 p-md-5 rounded my-2 my-md-4 w-100" style="max-width: 800px;">
    <h2 class="text-center text-custom mb-4 border-bottom pb-2">Roulette rules</h2>
    <p>A roulette wheel consists of a spinning disk with divisions around its edge that revolves around the base of a bowl. A ball is spun around the outside of the bowl until eventually ball and wheel come to rest with the ball in one of the divisions.</p>
    <p>Prior to rolling the ball, people place bets on what number will come up by laying down chips on a betting mat, the precise location of the chips indicating the bet being made.</p>
    <h4 class="text-center text-custom mb-4 border-bottom pb-2">Roulette payouts</h4>
    <ul>
        <li>Single number bet pays 35 to 1. Also called “straight up.”</li>
        <li>Double number bet pays 17 to 1. Also called a “split.”</li>
        <li>Three number bet pays 11 to 1. Also called a “street.”</li>
        <li>Four number bet pays 8 to 1. Also called a “corner bet.”</li>
        <li>Five number bet pays 6 to 1. Only one specific bet which includes the following numbers: 0-00-1-2-3.</li>
        <li>Six number bet pays 5 to 1. Example: 7, 8, 9, 10, 11, 12. Also called a “line.”</li>
        <li>Twelve numbers or dozens (first, second, third dozen) pays 2 to 1.</li>
        <li>Column bet (12 numbers in a row) pays 2 to 1.</li>
        <li>18 numbers (1-18) pays even money.</li>
        <li>18 numbers (19-36) pays even money.</li>
        <li>Red or black pays even money.</li>
        <li>Odd or even bets pay even money.</li>
    </ul>
    <div class="row">
        <a href="viewgames.php" class="btn btn-warning">Take me back to the games page</a>
    </div>
    </div>
 </main>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>
<?php include '../includes/footer.php'; ?>

