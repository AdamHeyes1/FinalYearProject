<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>
<?php
//Dont let user access if already logged in
if (isset($_SESSION['usersId'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

<!-- Make sure the body covers the height of the screen -->
<body class="d-flex flex-column min-vh-100">  
    <main class="flex-grow-1 d-flex align-items-center justify-content-center">
        <div class="container logInContainer bg-white shadow-lg p-3 p-md-5 rounded my-2 my-md-4 w-100" style="max-width: 85%;">
        <!-- Container for the form -->
            <h2 class="text-custom mb-4">Login</h2> 
            <form action="../includes/login.inc.php" method="post">
                <?php
                //Check for errors and submit feedback
                if(isset($_GET["error"])){
                    if($_GET["error"] == "emptyinput"){
                        echo '<div class="alert alert-danger" role="alert">Fill in all fields!</div>';
                    }
                    else if($_GET["error"] == "incorrectLogin"){
                        echo '<div class="alert alert-danger" role="alert">Incorrect login information!</div>';
                    }
                }
                ?>

                <!-- inputs-->
                <div class="row mb-3"> 
                    <div class="col">
                    <label for="username" class="form-label fw-bold">Username or Email</label>
                    <input type="text" name="username" class="form-control" placeholder="Enter Username or Email">
                    </div>
                </div>
                <div class="row mb-3"> 
                    <div class="col">
                    <label for="password" class="form-label fw-bold">Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter Password">
                    </div>
                </div>    
                <div class="row mb-2">
                    <button type="submit" name="submit" class="btn btn-warning">Log in</button>
                </div>
                <div class="row mb-2">
                    <input class="btn btn-outline-danger" type="reset" value="Reset">
                </div>
                <div class="row">
                    <a href="signup.php" class="btn btn-outline-success">Create an account!</a>
                </div>

                
            </form>
    </main>
</div>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>
<?php include '../includes/footer.php'; ?>

