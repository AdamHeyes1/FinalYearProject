<?php require_once "../includes/dbh.con.inc.php";  ?>

<?php 
session_start();

if (!isset($_SESSION['usersId'])) {
    header("Location: /5230Comp/CurrentProj1/app/login.php");
    exit();
}
?>


<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Home page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>
	<body class="d-flex flex-column min-vh-100">
		<header>
			<div class="container mb-4">
				<h1>Roulette</h1>
			</div>
		</header>
		<main class="flex-grow-1 d-flex align-items-center justify-content-center h-100">
			<div class="container logInContainer bg-white shadow-lg p-4 rounded w-100">
				<h1 class="text-danger">We're sorry, this game is currently unavailible!</h1>	
                <a href="home.php" class="btn btn-warning mt-3">Take me home</a>
	
			</div>
		</main>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
		<script src="../js/script.js"></script>
		<?php include '../includes/footer.php'; ?>
	</body>
</html>