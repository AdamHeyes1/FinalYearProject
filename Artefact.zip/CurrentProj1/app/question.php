<?php require_once "../includes/dbh.con.inc.php";  ?>
<?php session_start(); ?>
<?php 
	//Ensure user is logged in
	if (!isset($_SESSION['usersId'])) {
		header("Location: login.php");
		exit();
	}

	// Set variables
	$index = (int) $_GET['n'];
	$questionsArray = $_SESSION['questionsArray'];
	$total = count($questionsArray);
	$questionNumber = $questionsArray[$index];


	//get question
	$query = "SELECT * FROM `questions`
				WHERE question_number = $questionNumber";

	// get result
	$result = $conn->query($query) or die($conn->error.__LINE__);

	$question = $result->fetch_assoc();

	//get choices
	$query = "SELECT * FROM `choices` 
				WHERE question_number = $questionNumber";

	// get results
	$choices = $conn->query($query) or die($conn->error.__LINE__);

	//Set date and usersId variable
	$current_date = date("Y-m-d");
	$usersId = $_SESSION["usersId"];

	//Check if there is a record of this user taking a quiz on the current day
	$sql = "SELECT * FROM scores WHERE usersId = ? AND DATE(quiz_date) = ?";
	$stmt = mysqli_stmt_init($conn);

    
	mysqli_stmt_prepare($stmt, $sql);
	mysqli_stmt_bind_param($stmt, "is", $usersId, $current_date);
	mysqli_stmt_execute($stmt);
	$resultData = mysqli_stmt_get_result($stmt);

	mysqli_stmt_close($stmt);

	//If user has taken a quiz already today, redirect to home page
	if($row = mysqli_fetch_assoc($resultData)){
		header("Location: home.php");
		exit();;
	}


?>

<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quiz page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>
	<body class="d-flex flex-column min-vh-100">  
		<header>
			<div class="container mb-1">
				<h1>General Knowledge Quiz</h1>
			</div>
		</header>
		<main class="flex-grow-1 d-flex align-items-center justify-content-center h-100">

		<div class="container bg-white shadow-lg p-4 rounded w-100">

			<h1 class="question">
				<?php echo $question['text']; ?>
			</h1>

			<form method="post" action="/5230Comp/CurrentProj1/includes/process.php" class="d-flex flex-column flex-grow-1">

				<ul class="choices flex-grow-1 mb-3 list-unstyled">
					<?php while($row = $choices->fetch_assoc()): ?>
						<li class="mb-2"><label class="d-flex align-items-center gap-2"><input class="form-check-input" type="radio" name="choice" value="<?php echo $row['id']; ?>"> <?php echo $row['text']; ?></label></li>
					<?php endwhile; ?>						
				</ul>
				
				<div class="mt-auto d-flex justify-content-between align-items-center pt-3 border-top">
					<div class="text-muted fw-bold">Question <?php echo $index + 1; ?> of <?php echo $total; ?></div>
						<button class="submit btn btn-warning" type="submit">Submit</button>
					</div>
					<input type="hidden" name="number" value="<?php echo $index; ?>" />
				</form>

			</div>
		</main>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
		<script src="../js/script.js"></script>
		<?php include '../includes/footer.php'; ?>

	</body>
</html>