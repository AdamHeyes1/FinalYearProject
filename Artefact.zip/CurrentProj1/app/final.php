<?php session_start(); ?>
<?php
//Ensure user is logged in
if (!isset($_SESSION['usersId'])) {
	header("Location: login.php");
	exit();
}
require_once "../includes/dbh.con.inc.php"; 

$pass_mark = 7;
//Award 1000 currency if score is 7 or more
if ($_SESSION['score'] >= $pass_mark && isset($_SESSION["usersId"])){
    $usersId = $_SESSION["usersId"];
    //get existing currency
    $stmt = $conn->prepare("SELECT currency FROM users WHERE usersId = ?");
    $stmt->bind_param("i", $usersId);
    $stmt->execute();
    $stmt->bind_result($currentCurrency);
    $stmt->fetch();
    $stmt->close();

    //Add 1000 to balance
    $newBalance = $currentCurrency + 1000;

    // Update balance in db
    $update = $conn->prepare("UPDATE users SET currency = ? WHERE usersId = ?");
    $update->bind_param("di", $newBalance, $usersId);
	$update->execute();
    $update->close();
}
	//Set date score and usersId and pass into db
    $date = date("Y-m-d H:i:s"); 
	$usersId = $_SESSION["usersId"];
	$score = $_SESSION["score"];
	$sql = "INSERT INTO scores (usersId, quiz_date, score) VALUES (?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);

    //Pass the users values from the form into the stmt
	mysqli_stmt_prepare($stmt, $sql);
    mysqli_stmt_bind_param($stmt, "isi", $usersId, $date, $score);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

	$conn->close();

	//Change the color of the box depending on pass or fail
	$borderColor = 'border-danger';
	if($_SESSION['score'] >= $pass_mark){
		$borderColor = 'border-success';
	}
	
?>


<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>
<?php include '../includes/welcomemsg.inc.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Score page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

	<body class=" d-flex flex-column min-vh-100">
		<header>
			<div class="container mb-1">
				<h1>Results</h1>
			</div>
		</header>
		<!-- output the result of the quiz-->
		<main class="flex-grow-1 d-flex align-items-center justify-content-center h-100">
			<div class="container border <?php echo $borderColor; ?>  bg-white shadow-lg p-4 rounded w-100" style="border-width: 3px !important;">

				<h2>You have completed the test!</h2>
				<p class="mt-3"><strong>Final Score:  <?php echo $_SESSION['score']; ?></strong></p>
				<?php
				if ($_SESSION['score'] >= $pass_mark){
					echo "✅ Congratulations you passed and have therefore been awarded 1000 VC!<br>";
				}
				else{
					echo "❌ Unfortnately you did not pass this time, so you will not receive any credits.<br>";
				}
				?>
				
				<?php $_SESSION['score'] = 0; ?>
				<a href="quiz.php" class="btn btn-warning mt-3">Take me back</a>
			</div>
		</main>
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
		<script src="../js/script.js"></script>
		<?php include '../includes/footer.php'; ?>
	</body>
</html>