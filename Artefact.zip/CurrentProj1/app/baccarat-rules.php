<!-- static information as these rules will not be changed and therefore do not need to be imported dynamically-->
<!-- https://news.williamhill.com/casino-guides/how-to-play-baccarat/-->

<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Baccarat Rules</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>

<!-- Make sure the body covers the height of the screen -->
<body class="d-flex flex-column min-vh-100">  
<main class="flex-grow-1 d-flex align-items-center justify-content-center">
    <div class="container bg-white shadow-lg p-3 p-md-5 rounded my-2 my-md-4 w-100" style="max-width: 800px;">
    <h2 class="text-center text-custom mb-4 border-bottom pb-2">Baccarat rules</h2>
    <p>The rules of baccarat require all the betting on any particular hand to be completed before the hand begins. The game then starts with two cards being dealt to each of two hands, known respectively as a Player hand and a Bank hand.</p>

    <p>The game objective in live baccarat is to predict which of those hands will subsequently acquire a total which is closest to 9. This is done by betting on the Bank hand, the Player hand, or else wagering that the round will finish as a tie.</p>

    <p>In calculating any hand total, all tens and ‘face’ cards have a value of zero, an ace has a value of one, and all remaining cards score at their face value</p>

    <p>However, if any hand should score higher than 9, that score is adjusted by subtracting 10 from the original total.</p>

    <p>The house rules at any particular venue will decide whether either the bank or player hands are entitled to draw a third card. And in any event, there will always be a maximum of three cards available for any hand.</p>

    <p>Those who correctly bet on a winning player hand qualify for a 1 to 1 payout. However, while those who correctly forecast a winning bank hand will also be eligible for a 1 to 1 payout, under baccarat rules they must also pay a 5% commission. This has the effect of reducing the payout odds on this hand to 19 to 20.</p>

    <p>A winning tie bet qualifies for a payout of 8-to-1.

    <h4 class="text-center text-custom mb-4 border-bottom pb-2">How to bet on baccarat</h4>

    <p>If you wager on the player hand and it comes nearest to nine, you win twice your stake.</p>
    <p>If you wager on the banker hand and it’s a winning hand, the payout is 95% of your stake. But don’t forget that totals above nine require you to drop the first digit to get the true value. For example 9 + 6 = 15, drop the ‘1’ = 5.</p>

    <p>A tie is the other betting option, which as mentioned will give you an 8-to-1 payout.</p>
    <p>Score sheets are available at live baccarat tables to help you keep in touch with your score.</p>

    <h4 class="text-center text-custom mb-4 border-bottom pb-2">Player hand</h4>

    <p>One thing which can be confusing about baccarat is the drawing of a third card. But the important thing to remember is: this is not a matter of strategy, these decisions are all covered by game rules and actioned by the dealer. So as a player you could simply ‘go with the flow’ – but it’s always a good idea to have some understanding of what may happen.</p>

    <p>When a player’s hand totals 0 to 5, or equals 10, a third card is drawn. If the total is 6 or 7, the action is known as a ‘stand’, which means no third card is drawn. Totals of 8 or 9 are described as ‘naturals’, and here too no third card can be drawn.</p>
    <h4 class="text-center text-custom mb-4 border-bottom pb-2">Bankers hand</h4>

    <p>The rules for a banker hand follow similar principles but are a little more detailed. Once again, the dealer is responsible for applying these rules and thus will announce the action to be taken. </p>
    <div class="row">
        <a href="viewgames.php" class="btn btn-warning">Take me back to the games page</a>
    </div>   
</div>
 </main>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>
<?php include '../includes/footer.php'; ?>

