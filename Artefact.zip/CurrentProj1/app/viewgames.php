
<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>
<?php include '../includes/welcomemsg.inc.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Games page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">

</head>

<body>



<?php
//Output prompt to get more virtual currency, if user is logged in, as well as the games container
if (isset($_SESSION["usersId"])) { 
?>
  <div class="container my-5">
      <div class="card text-center shadow-lg p-4 bg-light">
          <h3 class="fw-bold" >🎮Play virtual games!</h3>
          <p class="lead">Spend your virtual currency on the games below! 🎉</p>
          <a href="quiz.php" class="btn btn-warning btn-lg mt-3">Ran out of virtual currency?</a>
      </div>
  </div>
    <!-- games container -->
    <div class="container my-4">
      <h2 class="text-center text-custom mb-4">Games</h2>
      <!-- output javascript -->
      <div class="row" id="gamesContainer"></div>
    </div>
<?php
//If user is not logged in, prompt them to create an account or signup
}
else{ 
?>
<div class="container bg-white border border-danger border-2 shadow-lg rounded my-4 p-5 d-flex flex-column justify-content-center" style="max-width: 80%; min-height: 60%">
  <h2 class="fw-bold mb-3 text-center">Risk-free gaming!</h2>
  <p class="text-muted mb-4 text-center">Log in or create an account to start playing!</p>   
  <div class="d-flex flex-column flex-md-row align-items-center justify-content-center gap-3">
      <a href="login.php" class="btn btn-warning btn-lg">Take me to log-in!</a>
      <a href="signup.php" class="btn btn-primary btn-lg" >Create an account!</a>
    </div>
</div>
<?php
}
?>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>
<?php include '../includes/footer.php'; ?>

