<?php
//get welcome message data from json file
$education_data = file_get_contents('../data/education.json'); 
$res = json_decode($education_data); 
if ($res !== null) {
  $title = $res->title;
  $description = $res->description;
  $image = $res->image;
} else {
    echo "Json error.";
}
?>

<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Education page</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
</head>

<!-- Make sure the body covers the height of the screen -->
<body class="d-flex flex-column min-vh-100">  
  <main class="flex-grow-1">


  <!-- welcome message container!-->
  <div class="container welcomeContainer text-left bg-white shadow-lg p-3 rounded my-4 mb-5" style="max-width: 90%;">
    <div class="row justify-content-center align-items-center">
      <div class="col-12 col-md-5">
      <img src="<?php echo $image; ?>" alt="Welcome Image" class="img-fluid rounded mb-2 right-image">
      </div>

      <div class="col-12 col-md-7">
        <h1 class="h1 mb-2 text-custom"><strong><?php echo $title; ?></strong></h1>
        <p class="lead text-muted"><?php echo $description; ?></p>
      </div>
    </div>
  </div>

  <!-- triggers carousel -->
  <div class="container my-4 bg-white shadow-lg p-3 rounded mb-5" style="width: 100%; max-width: 80%; min-height: 250px;">
    <h2 class="text-center text-custom mb-4"><strong>🎰Triggers⚠️</strong></h2>
      <div id="carousel" class="carousel slide" data-bs-ride="carousel">
          <div class = "row align-items-center">
            
          <div class=" col-1 d-flex justify-content-center">
            <button class="carousel-control-prev g-2 " type="button" data-bs-target="#carousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
            </button>
          </div>

          <div class="col-10">
            <div class="carousel-inner" id="carousel-inner1">
                <!-- javascript output here -->
            </div>
          </div>

          <div class=" col-1 d-flex justify-content-center">
            <button class="carousel-control-next" type="button" data-bs-target="#carousel" data-bs-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- youtube video -->
    <div class="d-flex justify-content-center mb-3">  
      <div class="ratio ratio-16x9" style=" max-width: 80%;">
      <iframe width="560" height="315" src="https://www.youtube.com/embed/QSi1zbLbXAs?si=E8oco1bmXHg6HgmT" title="Gambling video" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" referrerpolicy="strict-origin-when-cross-origin" allowfullscreen></iframe>    </div>
    </div>

    <div class="container my-4 bg-white shadow-lg p-3 rounded text-muted small border border-primary border-2" style="width: 100%; max-width: 80%;">
      🎥 The video above explains is a Ted Talk by Patrick Chester who explains his struggles with gambling addiction.
    </div>

    <!-- Online gambling infleuences -->
  <div class="container my-4 mt-4" style="max-width: 80%;">
    <h2 class="text-center text-custom mb-4">How has online gaming influenced gambling addiction?</h2>
    <!--Javascript here -->
    <div class="row" id="featuresContainer1"></div>
  </div>

  <h2 class="text-center text-custom mb-4">Theories which explain gambling addction...</h2>

  <div class="container mt-4 mb-5 d-flex justify-content-center" style="max-width: 80%;">
    <div class="row align-items-center" id="theoriesContainer" style="max-width: 100%;">
      <!-- Javascript here-->
    </div>
  </div>
  
  </main>
</body>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
<script src="../js/script.js"></script>

</body>
</html>
<?php include '../includes/footer.php'; ?>

