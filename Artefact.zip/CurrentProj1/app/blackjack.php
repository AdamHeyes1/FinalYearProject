<?php
//start session and set usercurrency varibale, or set it to 0 if its null
session_start();
$playerMoney = $_SESSION["userCurrency"] ?? 0;

//Redirect to login page is not logged in
if (!isset($_SESSION['usersId'])) {
    header("Location: /5230Comp/CurrentProj1/app/login.php");
    exit();
}
?>

<?php include '../includes/secondarynav.php'; ?>
<?php include '../includes/navbar.php'; ?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blackjack</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../css/stylistic.css" rel="stylesheet"> 
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
  <script src="jquery-3.7.1.min.js"></script>
</head>

<html>
    <body class="d-flex flex-column min-vh-100">  

    <!-- timeout container-->
    <div class="container border border-danger border-2 bg-white shadow-lg p-3 p-md-5 rounded my-2 my-md-4" id="timeout" style="max-width: 80%; display: none;">
            <h2><strong>You have been playing for 10 minutes!</strong></h2> 
            <a id="ignoreTimeout" class='btn btn-primary btn-lg mt-3' >Carry on playing!</a>
            <a href='support.php' class='btn btn-warning btn-lg mt-3' >View support tools!</a>
    </div>


    <main class="flex-grow-1 d-flex align-items-center justify-content-center">    
        <div class="container bg-white shadow-lg p-3 p-md-5 rounded my-2 my-md-4 w-100" style="max-width: 65%; ">

            <!-- title and message board-->
            <h1 class="text-center">Blackjack</h1><br>
            
            <h2 id="message-board" class="alert alert-secondary text-center"></h2>

            <div class="row justify-content-center mb-2">
                <!-- Dealer cards -->
                <div class="col-md-5 d-flex flex-column border border-dark rounded p-3 bg-light shadow mx-3" style="min-height: 20%;">
                    <h3 class="text-center">Dealer's Cards</h3>
                    <div id="dealer-cards" class="d-flex flex-wrap justify-content-center align-items-center" style="min-height: 10%;"></div>
                    <div id="dealer-score" class="score-box text-center mt-3">Dealer Score: 0</div>
                </div>
                <!-- Player cards -->
                <div class="col-md-5 d-flex flex-column border border-dark rounded p-3 bg-light shadow" style="min-height: 20%;">
                    <h3 class="text-center">Player's Cards</h3>
                    <div id="player-cards" class="d-flex flex-wrap justify-content-center align-items-center" style="min-height: 10%;"></div>
                    <div id="player-score" class="score-box text-center mt-3">Player Score: 0</div>
                </div>
            </div>


            <!-- buttons -->
             <div class="row justify-content-center mb-2" style="min-width: 50%;">
                    <div class="col-md-5 border border-dark rounded pt-3 bg-light shadow mx-3" style="min-width: 50%;">
                        <form name="blackjack" onSubmit="newGame(); return false;">
                            <div class="d-flex justify-content-between ">
                            <input type='submit' class="btn btn-primary" id='new-game-button' value='Deal'/>
                            <input type='button' class="btn btn-primary" id='hit-button' value='Hit' onclick='hit();' disabled/>
                            <input type='button' class="btn btn-primary" id='stand-button' value='Stand' onclick='stand();' disabled/>
                            </form>
                        </div>
                    </div>
                </div>

            <!-- bet box -->
            <div class="card border-success shadow-lg" style="max-width: 250px; margin: auto;">
                <div class="card-body">
                    <h5 id="player-money" class="fw-bold text-success">$100</h5>
                        <label for="bet" class="fw-bold d-block">Bet Amount:</label>
                        <div class="input-group">
                            <span class="input-group-text"></span>
                            <input type="number" id="bet" class="form-control text-center" value="10" min="1" max="<?php echo $playerMoney; ?>"/>
                        </div>
                </div>
            </div>

            <script src="../js/blackJackV2.0.js">
            </script>
        </form>
    </main>
    </body>

</html>

<script>
    
    //Show timeout message 
    function showMsg(){
        $("#timeout").fadeIn();
        document.getElementById("timeout").scrollIntoView();  
    }

    //Show message after 10 mins
    function begin(){
        setTimeout(() => {
        showMsg();
        }, 600000);
    }

    //Call for first time
    begin();

    //Clear timeout and restart timer when use wants to carry on playing
    document.getElementById('ignoreTimeout').addEventListener('click', () => {        
        clearTimeout(timeout);
        $("#timeout").hide();
        begin();
    });
   
</script>

<?php include '../includes/footer.php'; ?>
