document.addEventListener("DOMContentLoaded", function() {
  //load features data from the features file
  fetch('../data/features.json')
  .then(response =>response.json())  
  .then(data => {
    //select features container
    const featuresContainer = document.getElementById('featuresContainer');
    //loop through each feature 
    data.features.forEach(feature=> {   
      //create a card for each feature
      const card = `
        <div class="col-md-4 mb-4 d-flex">
            <div class="card shadow-lg h-100 w-100">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title fw-bold">${feature.title}</h5>
                    <p class="card-text">${feature.description}</p>
                </div>
            </div>
        </div>`;

      //add each card to the features container
      featuresContainer.innerHTML += card;
    });
  })

   //load each factor from the educational features file
   fetch('../data/features-education.json')
   .then(response =>response.json())  
   .then(data => {
     //select educational features container
     const featuresContainer = document.getElementById('featuresContainer1');
     //loop through each factor 
     data.features.forEach(feature=> {   
       //create a card for each feature
       const card = `
         <div class="col-md-4 mb-4 d-flex">
             <div class="card shadow-lg h-100 w-100">
                 <div class="card-body d-flex flex-column">
                     <h5 class="card-title fw-bold">${feature.title}</h5>
                     <p class="card-text">${feature.description}</p>
                 </div>
             </div>
         </div>`;
 
       //add each card to the features container
       featuresContainer.innerHTML += card;
     });
   })

   fetch('../data/theories-education.json')
  .then(response => response.json())
  .then(data => {
    //Select theories container
    const featuresContainer = document.getElementById('theoriesContainer');
    //Create a card for each theory
    data.theories.forEach(theory => {
      const card =` 
      <div class="col-12 mb-4">
        <div class="bg-white p-3 rounded row align-items-start">    
          <div class="col-md-2 text-center">
            <img src="${theory.img}" alt="${theory.alt_text}" class="img-fluid">
          </div>
          <div class="col-md-10">
            <h4 class="fw-bold">${theory.theory_title}</h4>
            <p>${theory.theory_description}</p>
          </div>
        </div>
      </div> ` ;
      //Add each card to container  
      featuresContainer.innerHTML += card;
    });
  })

  fetch('../data/resources-support.json')
  .then(response => response.json())
  .then(data => {
    //Select resources container
    const featuresContainer = document.getElementById('resourcesContainer');

    data.resources.forEach(resource => {
      //Create card for each resource
      const card =` 
      <div class="col-12 mb-4">
        <div class="bg-white p-3 rounded row align-items-start">    
          <div class="col-md-2 text-center">
            <img src="${resource.img}" alt="${resource.alt_text}" class="img-fluid">
          </div>
          <div class="col-md-10">
            <h4 class="fw-bold">${resource.title}</h4>
            <p>${resource.description}</p>
            <a href="${resource.link}" target="_blank" class="btn btn-success mt-4 ">View page...</a>
          </div>
        </div>
      </div> ` ;
        //Add each card to container
      featuresContainer.innerHTML += card;
    });
  })



  .catch(error=>console.error('Error:', error));  

    //load carousel data from carousel file
    fetch('../data/carousel.json')
      .then(res=> res.json())  
      .then(data=> {
        //select carousel container
        const carouselInner = document.getElementById('carousel-inner') ;
        
        //loop through each item
        data.carousel.forEach((item, index) =>{
          //Make first slide actuve
          const activeClass = index === 0 ? 'active' : ''; 

  
          //create single item
          const carouselItem = `
            <div class="carousel-item ${activeClass}">
              <img src="${item.image}" class="d-block w-100" alt="${item.link_title}" >
              <div class="d-flex justify-content-center mt-1">
                <a href="${item.link}" class="btn btn-warning">${item.link_title}</a>
              </div>
            </div>`;
          
          //add each carousel item to the carousel container
          carouselInner.innerHTML+= carouselItem;
        });
      })
      .catch(error => console.error('Error:',error)) ;  
  
    //load carousel data from carouselEducation file
    fetch('../data/educationCarousel.json')
    .then(res=> res.json())  
    .then(data=> {
      //select educational carousel container
      const carouselInner = document.getElementById('carousel-inner1') ;
      
      //loop through each item
      data.carousel.forEach((item, index) =>{
        //Make first slide active
        const activeClass = index === 0 ? 'active' : ''; 
        //create carousel item
        const carouselItem = `
          <div class="carousel-item ${activeClass} align-items-center text-center" style=" overflow: auto;">

            <div class="d-flex justify-content-center mt-1">
              <h4><strong>${item.trigger_title}</strong></h4>
            </div>
            <div class="d-flex justify-content-center mt-1">
              <p>${item.trigger_text}</p>        
            </div>
          </div>`;
        
        //add each carousel item to the carousel container
        carouselInner.innerHTML+= carouselItem;
      });
    })
    .catch(error => console.error('Error:',error)) ;  
  })

  //load games from games file
  fetch('../data/games.json')
  .then(response =>response.json())  //parse to json
  .then(data => {
    //select games container
    const gamesContainer = document.getElementById('gamesContainer');
    //loop through each feature 
    data.games.forEach(game=> {   
      //create a card for each game
      const card = `
        <div class="col-md-4 mb-4 d-flex">
            <div class="card shadow-lg h-100 w-100">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title fw-bold">${game.title}</h5>
                    <p class="card-text">${game.description}</p>
                    <div class="d-flex align-items-center gap-2">
                      <a href="${game.link}" class="btn btn-warning flex-grow-1 h-100">${game.link_title}</a>    
                      <a href="${game.rules_link}" class="btn btn-primary w-15 h-100 d-flex align-items-center justify-content-center" title="View Rules">
                        <i class="fas fa-info-circle"></i>
                      </a>   
                    </div>
                               
                </div>
            </div>
        </div>`;

      //add each card to the features container
      gamesContainer.innerHTML += card;
    })
  });

  
  