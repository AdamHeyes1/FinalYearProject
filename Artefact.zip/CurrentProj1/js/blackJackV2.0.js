/*jslint node: true*/
/*eslint no-console: ["error", { allow: ["log"] }] */
/*global document*/
"use strict";

//output card image
function getCardImage(card) {
    //map suit and rank 
    const mapSuit = {"spades":0,"clubs":1,"diamonds": 2,"hearts":3};
    const mapRank = {"A": 1,"J": 11,"Q": 12,"K": 13};  
    let rank = mapRank[card.rank] || card.rank; 
    let suitIndex = mapSuit[card.suit];

    //set the file path to get card image
    let fileName= `${suitIndex}-${rank}.png`;
    let imagePath= `http://localhost/5230Comp/CurrentProj1/img/cards/${fileName}`;

    //return card image
    return `<img src="${imagePath}"alt="${card.rank} of ${card.suit}" class="card-img">`;
}

//Initialze cards pulled variable
var numCardsPulled = 0;

//Initialize player and dealer objects
var player = {
    cards: [],
    score: 0,
    money: 100 
};
var dealer = {
    cards: [],
    score: 0
};

//Create deck
var deck = {  
    deckArray: [],
    initialize: function () {
        var suitArray, rankArray, s, r;
        suitArray = ["clubs", "diamonds", "hearts", "spades"];
        rankArray = [2, 3, 4, 5, 6, 7, 8, 9, 10, "J", "Q", "K", "A"];
        //Loop through each suit
        for (s = 0; s < suitArray.length; s += 1) {
            //Loop through each rank and set the card values
            for (r = 0; r < rankArray.length; r += 1) {
                this.deckArray[s * 13 + r] = {
                    rank: rankArray[r],
                    suit: suitArray[s]
                };
            }
        }
    },
    shuffle: function () { 
        var temp, i, rnd;
        //Loop through each card and swap it with another
        for (i = 0; i < this.deckArray.length; i += 1){
            rnd = Math.floor(Math.random()*this.deckArray.length);
            temp = this.deckArray[i];
            this.deckArray[i] = this.deckArray[rnd];
            this.deckArray[rnd]= temp;
        }
    }
};

//Set the players money and initialize deck and shucffle cards
document.getElementById("player-money").innerHTML = "VC: " + player.money;
deck.initialize();
deck.shuffle();

//Calculate the value of the cards
function getCardsValue(a) {
    var cardArray = [],
        sum = 0,
        i = 0,
        aceCount = 0;
    cardArray = a;
    //Loop through each card, and set the value
    for (i; i < cardArray.length; i += 1) {
        if (cardArray[i].rank === "J" || cardArray[i].rank === "Q" || cardArray[i].rank === "K") {
            sum += 10;
        } else if (cardArray[i].rank === "A") {
            sum += 11;
            aceCount += 1;
        } else {
            sum += cardArray[i].rank;
        }
    }
    //Handle aces
    while (aceCount > 0 && sum > 21) {
        sum -= 10;
        aceCount -= 1;
    }
    return sum;
}

//Handle the bet outcome depending on if player wins or loses
function bet(outcome) {
    var playerBet = document.getElementById("bet").valueAsNumber;
    //Update players balance
    if (outcome === "win") {
        player.money += playerBet;
    }
    if (outcome === "lose") {
        player.money -= playerBet;
    }
    // Send updated balance to database
    updateBalance();
}


//Reset all elements for a new game
function resetGame() {
    numCardsPulled = 0;
    player.cards = [];
    dealer.cards = [];
    player.score = 0;
    dealer.score = 0;
    deck.initialize();
    deck.shuffle();
    document.getElementById("hit-button").disabled = true;
    document.getElementById("stand-button").disabled = true;
    document.getElementById("bet").disabled = false;
    document.getElementById("bet").max = player.money;
    document.getElementById("new-game-button").disabled = false;
}

//Change the color of the text on message board depending on win lose or draw
function changeColor(color) {
    let messageContainer = document.getElementById("message-board");
    messageContainer.style.color = color;
}

//Handle outcomes at end of game
function endGame() {
    if (player.score === 21) {
        document.getElementById("message-board").innerHTML = "You win! You got blackjack." + "<br>" + "click Deal to keep playing!";
        bet("win");
        changeColor("green");
        document.getElementById("player-money").innerHTML = "VC: " + player.money;
        resetGame();
    }
    if (player.score > 21) {
        document.getElementById("message-board").innerHTML = "You went over 21! The dealer wins" + "<br>" + "click Deal to keep playing!";
        bet("lose");
        changeColor("red");
        document.getElementById("player-money").innerHTML = "VC: " + player.money;
        resetGame();
    }
    if (dealer.score === 21) {
        document.getElementById("message-board").innerHTML = "You lost. Dealer got blackjack" + "<br>" + "Click deal to keep playing!";
        bet("lose");
        changeColor("red");
        document.getElementById("player-money").innerHTML = "VC: " + player.money;
        resetGame();
    }
    if (dealer.score > 21) {
        document.getElementById("message-board").innerHTML = "Dealer went over 21! You win!" + "<br>" + "Click deal to keep playing!";
        bet("win");
        changeColor("green");
        document.getElementById("player-money").innerHTML = "VC: " + player.money;
        resetGame();
    }
    if (dealer.score >= 17 && player.score > dealer.score && player.score < 21) {
        document.getElementById("message-board").innerHTML = "You win! You beat the dealer." + "<br>" + "Click deal to keep playing!";
        bet("win");
        changeColor("green");
        document.getElementById("player-money").innerHTML = "VC: " + player.money;
        resetGame();
    }
    if (dealer.score >= 17 && player.score < dealer.score && dealer.score < 21) {
        document.getElementById("message-board").innerHTML = "You lost. Dealer had the higher score." + "<br>" + "Click deal to keep playing!";
        bet("lose");
        changeColor("red");
        document.getElementById("player-money").innerHTML = "VC: " + player.money;
        resetGame();
    }
    if (dealer.score >= 17 && player.score === dealer.score && dealer.score < 21) {
        document.getElementById("message-board").innerHTML = "You tied! " + "<br>" + "Click deal to keep playing!";
        resetGame();
    }
    if (player.money <= 0) {
        document.getElementById("new-game-button").disabled = true;
        document.getElementById("hit-button").disabled = true;
        document.getElementById("stand-button").disabled = true;
        document.getElementById("message-board").innerHTML = "You are out of money!<br><a href='/5230Comp/CurrentProj1/app/home.php' class='btn btn-warning'>Go to Home Page</a>";
    }
    
}

//Function for dealer to get a new card
function dealerDraw() {
    dealer.cards.push(deck.deckArray[numCardsPulled]);
    dealer.score = getCardsValue(dealer.cards); 
    document.getElementById("dealer-cards").innerHTML = "";
    //Output the dealers cards
    for (let i = 0; i < dealer.cards.length; i++){
        document.getElementById("dealer-cards").innerHTML += getCardImage(dealer.cards[i]);
    }
    // Update dealer's score
    document.getElementById("dealer-score").innerHTML = "Dealer Score: " + dealer.score;
    numCardsPulled += 1;
}

//Create new game
function newGame() {
    document.getElementById("new-game-button").disabled = true;
    document.getElementById("hit-button").disabled = false;
    document.getElementById("stand-button").disabled = false;
    document.getElementById("bet").disabled = true;
    document.getElementById("message-board").innerHTML = "";
    document.getElementById("dealer-cards").innerHTML = "";
    document.getElementById("player-cards").innerHTML = "";
    hit();
    hit();
    dealerDraw();
    endGame();
}

//Add card to players hand
function hit() {
    player.cards.push(deck.deckArray[numCardsPulled]); 
    player.score = getCardsValue(player.cards); 
    document.getElementById("player-cards").innerHTML = "";
    for (let i = 0; i < player.cards.length; i++) {
        document.getElementById("player-cards").innerHTML += getCardImage(player.cards[i]);
    }    
    document.getElementById("player-score").innerHTML = `Player Score: ${player.score}`;
    numCardsPulled += 1;
    if (player.score >= 21) { 
        endGame(); 
    }
}

//Function for dealer to get new card until they get 17 or bust
function stand() {
    while (dealer.score < 17) {
        dealerDraw();
    }
    endGame();
}

//Get users currency and display it in the bet box
fetch("/5230Comp/CurrentProj1/includes/getbalance.php")
    .then(response => response.json())
    .then(data => {
        if (data.error){
            console.error("Error:",data.error);
            return;
        }
        player.money = data.balance; 
        document.getElementById("player-money").innerHTML=`VC: ${player.money}`;
    })
    .catch(error => console.error("Error:", error));

deck.initialize();
deck.shuffle();

//Update users balance in db
function updateBalance() {
    var xmlhttp = new XMLHttpRequest();
    var newBalance = player.money;
    xmlhttp.onreadystatechange = function (){
        if (xmlhttp.readyState===4 && xmlhttp.status===200){
            console.log(xmlhttp.responseText); 
        }
    };
    xmlhttp.open("GET", "../app/update_balance.php?newBalance="+newBalance, true);
    xmlhttp.send();
}
