$(document).ready(function () {
    function load() {
        $.ajax({ 
            //send GET request for balance
            type: "GET",
            url: "/5230Comp/CurrentProj1/includes/getbalance.php", 
            dataType: "json",               
            success: function (response) {
                //Update users balance
                $(".user-balance").html("VC: "+response.balance);
                //Call again after a second
                setTimeout(load, 1000);
            }
        });
    }
    load(); 
});