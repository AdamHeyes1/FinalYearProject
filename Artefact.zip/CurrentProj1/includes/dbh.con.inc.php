<?php
//Create connection
$servername = "localhost"; 
$dbUsername = "root"; 
$dbPassword = "root"; 
$dbName = "project"; 

$conn = mysqli_connect($servername, $dbUsername, $dbPassword, $dbName);

if (!$conn) {
    die("Error: Database connection failed - " . mysqli_connect_error());
}
