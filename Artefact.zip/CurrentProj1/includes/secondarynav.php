<?php session_start(); ?>
 
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="/5230Comp/CurrentProj1/js/getbalance.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css">


<nav class="navbar navbar-expand-lg" style="background-color: var(--secondary-color);"> 
  <!-- escape hatch in the top left !-->
  <div class="container-fluid">
    <a class="navbar-brand text-white" href="/5230Comp/CurrentProj1/app/home.php">
      <i class="fa fa-home" aria-hidden="true"></i> Home

    </a>
    <!-- login and signup links !-->
    <div class="ms-auto">
      <?php 
      if(isset($_SESSION["usersId"])){
        echo '<div class="d-flex align-items-center gap-3">';
        echo '<span class="user-balance fw-bold text-light btn btn-info">Loading...</span>';
        echo '<a href="/5230Comp/CurrentProj1/includes/logout.inc.php" class="btn btn-danger">Log Out</a>';
        echo '</div>';
      }
      else{
        echo '<a href="/5230Comp/CurrentProj1/app/signup.php" class="btn btn-warning me-2">Sign Up</a>';
        echo '<a href="/5230Comp/CurrentProj1/app/login.php" class="btn btn-primary ">Login</a>'; 
      }
      ?>
    </div>
  </div>
</nav>