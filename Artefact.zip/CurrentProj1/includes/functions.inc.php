<?php include 'dbh.con.inc.php'; ?>

<?php

//Check that all fields are filled in
function emptyInputSignup($name, $email, $username, $password, $confirmPassword, $lastName){
    $result;
    //If any fields are empty, return an error
    if(empty($name) || empty($email) || empty($username) || empty($password) || empty($confirmPassword) || empty($lastName)){
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

//Ensure only valid characters are accepted in username
function invalidUsername($username){
    $result;
    //Use the preg match function to check for specific characters in the username
    if(!preg_match("/^[a-zA-Z0-9]*$/", $username)){
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

//function to check that the email is valid
function invalidEmail($email){
    $result;
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

//Check that the confirm password and password match
function passwordMatch($password, $confirmPassword){
    $result;
    if($password !== $confirmPassword){
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

//Check that the password contains 6 chars and one uppercase letter
function invalidPassword($password) {
    $result = false;

    // Check if password is at least 6 characters long
    if (strlen($password)<6) {
        $result = true;
    }
    // Check if password contains at least one uppercase letter
    elseif (!preg_match('/[A-Z]/', $password)){
        $result = true;
    }
    return $result;
}

//Check if the username or email is taken
function usernameExists($conn, $username, $email){
    //Select any records in the user table where the username and email match the new input
    $sql = "SELECT * FROM users WHERE usersUid = ? or usersEmail = ?;";
    $stmt = mysqli_stmt_init($conn);
    //Return an error is the query fails
    if(!mysqli_stmt_prepare($stmt, $sql)){
        header("location: ../app/signup.php?error=stmtfailed");
        exit();
    }
    mysqli_stmt_bind_param($stmt, "ss", $username, $email);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    //Return an error if the data matches a username or password in the database
    if($row = mysqli_fetch_assoc($resultData)){
        return $row;
    }
    else{
        $result = false;
        return $result;
    }
    mysqli_stmt_close($stmt);
}

//Create users account
function createUser($conn, $name, $email, $username, $password, $lastName, $anonymous){
    //Insert values into database
    $sql = "INSERT INTO users (usersName, usersEmail, usersUid, usersPwd, usersSecondName, usersAnonymous, currency) VALUES (?, ?, ?, ?, ?, ?, ?);";
    $stmt = mysqli_stmt_init($conn);
    //Error handler
    if(!mysqli_stmt_prepare($stmt, $sql)){
        header("location: ../app/signup.php?error=stmtfailed");
        exit();
    }
    //Hash the password for security
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    $initalCurrency = (int) 1000;

    //Pass the users values from the form into the stmt
    mysqli_stmt_bind_param($stmt, "sssssii", $name, $email, $username, $hashedPassword, $lastName, $anonymous, $initalCurrency);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    //Pass success message into the URL
    header("location: ../app/signup.php?error=success");
    exit();
}

//Ensure the username and password are not empty on the login page
function emptyInputLogin($username, $password){
    $result;
    if(empty($username) || empty($password)){
        $result = true;
    }
    else{
        $result = false;
    }
    return $result;
}

//Login the user
function loginUser($conn, $username, $password){
    //Check the username exists and if it does not return an error
    $usernameExists = usernameExists($conn, $username, $username);
    if($usernameExists === false){
        header("location: ../app/login.php?error=incorrectLogin");
        exit();
    }

    $passwordHashed = $usernameExists["usersPwd"];

    $checkPassword = password_verify($password, $passwordHashed);

    //Check the password matches the username
    //If password is incorrect return error
    if ($checkPassword === false){
        header("location: ../app/login.php?error=incorrectLogin");
        exit();
    }
    //If correct, start session and log the user in
    else if ($checkPassword === true){
        session_start();
        $_SESSION["usersId"] = $usernameExists["usersId"];
        $_SESSION["usersUid"] = $usernameExists["usersUid"];
        $_SESSION["userCurrency"] = $usernameExists["currency"];

        header("location: ../app/home.php");
        exit();
        
    }
}


