<!-- navbar -->
<?php session_start(); ?>
<nav class="navbar navbar-expand-lg bg-custom navbar-dark mb-4 ">
  <div class="container-fluid">

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="collapse navbar-collapse" id="navbarNav" >
      <!-- navbar elements -->
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link text-white" href="/5230Comp/CurrentProj1/app/home.php">Home</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/5230Comp/CurrentProj1/app/viewgames.php">View Games</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/5230Comp/CurrentProj1/app/quiz.php">Daily quiz</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/5230Comp/CurrentProj1/app/support.php">Support</a></li>
        <li class="nav-item"><a class="nav-link text-white" href="/5230Comp/CurrentProj1/app/education.php">Educational Resources</a></li>
        <?php
        if (isset($_SESSION["usersId"]) && $_SESSION["usersId"] == 25) {
          echo '<li class="nav-item"><a class="nav-link text-white" href="/5230Comp/CurrentProj1/app/add.php">Add question</a></li>';
        }
        ?>
      </ul>
    </div>
  </div>
</nav>

