<?php

//Store user inputs in variables
if(isset($_POST["submit"])){
    $username = $_POST["username"];
    $password = $_POST["password"];

    require_once 'dbh.con.inc.php';
    require_once 'functions.inc.php';

    //call the empty input login if the username or password is not filled in
    if(emptyInputLogin($username, $password) !== false){
        header("location: ../app/login.php?error=emptyinput");
        exit();
    }
    //Call the login user function if the user has filled in bothe the username and password
    loginUser($conn, $username, $password);
    
}
else{
    header("location: ../app/login.php");
    exit();
}



