<?php
session_start(); 
include "dbh.con.inc.php"; 

//Check if users logged in
if (!isset($_SESSION["usersId"])) {
    echo json_encode(["error" => "user isnt loggged in"]);
    exit();
}

$user_id = $_SESSION["usersId"];

//Select currency in the database
$sql = "SELECT currency FROM users WHERE usersId = ?;";
$stmt = mysqli_stmt_init($conn);
//Return an error is the query fails
if(!mysqli_stmt_prepare($stmt, $sql)){
    exit();
}
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);

$resultData = mysqli_stmt_get_result($stmt);

//Return currency or error if no data found
if ($row = mysqli_fetch_assoc($resultData)) {
    echo json_encode(["balance" => $row["currency"]]); 
} else {
    echo json_encode(["error" => "user not found"]);
}

mysqli_stmt_close($stmt);
?>


