<?php require_once "../includes/dbh.con.inc.php";  ?>
<?php session_start(); ?>
<?php

	// Check to see if score is set
	if(!isset($_SESSION['score'])){
		$_SESSION['score'] = 0;
	}

	if($_POST){
		//Set variables
		$index = (int) $_POST['number'];
		$questionsArray = $_SESSION['questionsArray'];
		$question_number = $questionsArray[$index];
		$selected_choice = $_POST['choice'];     

		//get correct choice
		$query = "SELECT * FROM `choices`
					WHERE question_number = $question_number AND is_correct = 1";

		// Get result
		$result = $conn->query($query) or die($conn->error.__LINE__);

		// Get row
		$row = $result->fetch_assoc();

		// Set the correct choice
		$correct_choice = $row['id'];

		// Compare
		if($correct_choice == $selected_choice){
			// Answer is correct
			$_SESSION['score']++;
		}


		// Check to see if this is the last question
		$next = $index + 1;
		$total = count($questionsArray);

		if($next >= $total){
			header("Location: ../app/final.php");
			exit();
		} else {
			header("Location: ../app/question.php?n=" . $next);
		}

	}
?>