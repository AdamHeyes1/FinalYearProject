<?php

//Check if something has been posted
if(isset($_POST["submit"])){
    $name = $_POST['firstName'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];
    $lastName = $_POST['lastName'];
    $anonymous = 0;

    require_once 'dbh.con.inc.php';
    require_once 'functions.inc.php';

    if(emptyInputSignup($name, $email, $username, $password, $confirmPassword, $lastName) !== false){
        header("location: ../app/signup.php?error=emptyinput");
        exit();
    }
    if(invalidUsername($username) !== false){
        header("location: ../app/signup.php?error=invalidusername");
        exit();
    }
    if(invalidEmail($email) !== false){
        header("location: ../app/signup.php?error=invalidemail");
        exit();
    }
    if(passwordMatch($password, $confirmPassword) !== false){
        header("location: ../app/signup.php?error=pwdConfirmError");
        exit();
    }
    if(usernameExists($conn, $username, $email) !== false){
        header("location: ../app/signup.php?error=usernameTaken");
        exit();
    }
    if(invalidPassword($password) !== false){
        header("location: ../app/signup.php?error=invalidPassword");
        exit();
    }

    createUser($conn, $name, $email, $username, $password, $lastName, $anonymous);
}
else{
    header("location: ../app/signup.php");
    exit();
}