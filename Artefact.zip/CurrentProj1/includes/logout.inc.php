<?php
//Destroy the session and return the user to the homepage
session_start();
session_unset();
session_destroy();

header("location: ../app/home.php");
exit();