<?php
//Retrive Welcome message data from file
$welcome_data = file_get_contents('../data/welcome.json'); 
$res = json_decode($welcome_data); 
//Assign data to variables
if ($res !== null) { 
  $title = $res->title;
  $description = $res->description;
  $image = $res->image;
} else {
    echo "Json error."; 
}

?>